﻿using calculateGPS;

calcGPS example = new calcGPS();
example.calculatePacket();